"""
logic/precedents.py - step ④: the Commission's market definitions for the rows kept after step ③ (the app finds and
cites, the lawyer decides).

    search_units(target, results, overrides, confirmed_target)   which searches are needed: ONE per target activity,
                                                                 covering the items of all its kept rows, both sides
    unit_input(unit, names)                                      the anonymised item list (ids such as [2.3])
    run_unit(ai, unit, names, retriever)                         query plan -> hybrid retrieval -> reflection, in a
                                                                 loop with three STOP conditions, then the
                                                                 citation check and the item check in code
    row_view(r, record, overrides)                               what one row of the table shows, assembled in code
    reusable(record, unit)                                       whether an earlier search still covers the unit

One search per target activity, so that one market keeps one name in all its rows and code can say where the
precedent puts each company's items; at most one rewrite of the queries (two attempts).

What the AI does here: write the queries; read the retrieved paragraphs and place every item in a market the
paragraphs define (or "none"). What code does: the retrieval, the loop and its STOP conditions, the check that every
cited paragraph was actually retrieved, the check that every item id exists, and every sentence shown in the table
(e.g. "different markets under the precedent"). Nothing in this file knows a sector.

Confidentiality: the query and reflection calls contain anonymised items only (names removed in code and checked
again before the call), grouped by activity number, with no company label; a remaining name blocks the call. The
retrieved decision paragraphs are public and are sent unchanged, even where a decision names a company
of the screen; such names are recorded in the audit log.
"""
import hashlib
import json
import re
import threading

from logic import rules, schemas
from logic.build_corpus import MARKET_LEVELS

MAX_ATTEMPTS = 2          # one rewrite of the queries
MAX_TYPES = 16            # types of product per search: one small reflection each. A lower limit left whole
                          # activities unsearched when a row had many items
MAX_EXTRA = 4             # items the query step left unassigned: searched on their own up to this many; the rest is
                          # searched per activity (its product line as the type), so that EVERY item is searched
MAX_REWRITE = 2           # types of product in the rewrite of one type
# Every type of product is searched with two questions, built in code. In the retrieval check (retrieval_check.py
# --forms), the Commission's question found a DEFINING paragraph more reliably than product words alone, but it also
# pulls in definitions of other products; the top 3 of each keeps both. The wording is legal, not sector knowledge.
QUERY_FORMS = ("relevant product market for {p}", "whether {p} constitutes a separate relevant product market")
HITS_PER_FORM = 3         # decision paragraphs kept per question (the Notice states principles and is not searched here)
POOL_PER_QUERY = 10       # hits asked from the retriever per question, before the Notice is left out
MAX_PARAGRAPHS = 14       # paragraphs per reflection of one type (its hits first, then their neighbours); +8 in the
                          # second attempt. One focused call per type of product with a few paragraphs: one large call
                          # with all products and paragraphs missed products although the right paragraph was in it
TYPE_PARALLEL = 16        # types of one search run at the same time; the AI gate allows MAX_PARALLEL requests at
                          # once in all
FALLBACK_ITEMS = 8        # items of an "Other activities" line used when a row names no items
SOURCE_DECISION = "Commission decision"

STOP_WORDS = {
    "all placed": "AI STOP: every item was placed in a market or found to have none",
    "no rewrite": "AI STOP: the reflection suggested no further search",
    "same paragraphs": "code STOP: the new search returned no new paragraphs",
    "attempts": f"hard STOP: {MAX_ATTEMPTS} attempts used",
    "blocked": "blocked: a company name was still in the text (no call was made)",
    "failed": "the call failed",
}
# The reflection may only report a conclusion that a paragraph it was sent states
NOT_STATED = "not stated in these paragraphs"
PARTLY = "defined, a further question left open"      # decided on one boundary, another left open
STATED = ("defined", "left open", PARTLY)
FIT_ONE, FIT_RANGE, FIT_UNCLEAR = "one market", "range across these markets", "one of these, unclear which"
FIT_SAME = "the same market in different decisions"     # one market, named differently in two decisions
NOT_LEVEL = "not stated"
# Levels of trade: a market's own level is the level of its SELLERS (a market for the supply of a product to shops is
# at the producers' level; a market in which shops sell to consumers is at retail level). An activity's own market is a
# market at its level of trade; a market for its products at another level is context, never its own market (Market
# Definition Notice (14)). No sector knowledge and no word list: the level comes from the curated metadata of the
# built-in decisions (build_corpus.MARKET_LEVELS) or from a passage of the decision verified word for word.
LEVEL_SAME, LEVEL_OTHER, LEVEL_UNKNOWN = "same", "other", "unknown"


# =============================================================== which searches are needed
def _kept(status):
    return status in ("candidate", "unclear", "added back by user")


def row_items(r, overrides, effective_status, dismissed_parts):
    """The items of one kept row that step ④ looks up, per side: the items that meet (horizontal) and the
    items of every vertical link the lawyer did not dismiss. A row that names no items (unclear, added back, or a link
    without items) uses each side's product line; an "Other activities" line uses its includes instead."""
    status = effective_status(r, overrides)
    if not _kept(status):
        return None
    off = set(dismissed_parts(r, overrides))
    d = r["decision"]
    a, b = [], []
    if status == "candidate":
        m = r.get("matches") or {}
        if d.get("horizontal") and "horizontal" not in off:
            a += m.get("a") or []
            b += m.get("b") or []
        named = {v.get("link"): v for v in r.get("vertical_items") or []}
        for link in d.get("vertical_links", []):
            if link in off:
                continue
            # a link without items (found by a code rule, or the AI named none for one side) uses that side's
            # product line, also in a row that has a horizontal overlap as well, so that the link is searched too
            v = named.get(link) or {}
            a += v.get("a") or _fallback_items(r["a"])
            b += v.get("b") or _fallback_items(r["b"])
    return {"a": list(dict.fromkeys(a or _fallback_items(r["a"]))),
            "b": list(dict.fromkeys(b or _fallback_items(r["b"])))}


def _fallback_items(act):
    items = rules.activity_items(act)
    if rules.category(act) == "other":
        return [i for i in items[1:] if i][:FALLBACK_ITEMS] or items[:1]
    return items[:1]


def search_units(results, overrides, effective_status, dismissed_parts, pair_id, target_order):
    """One unit per target activity that has at least one kept row: the target activity, every portfolio activity in
    its kept rows, and the items each of them contributes. target_order: the target's activity IDs in display order.
    Returns a list of units, in the target's order."""
    units = {}
    for r in results:
        items = row_items(r, overrides, effective_status, dismissed_parts)
        if items is None:
            continue
        ta, pa = r["a"], r["b"]
        u = units.setdefault(ta["aid"], {"target_aid": ta["aid"], "target_product": ta.get("product", ""),
                                         "activities": {}, "rows": []})
        u["rows"].append(pair_id(r))
        for side, act, who in (("a", ta, "target"), ("b", pa, r["portco"])):
            entry = u["activities"].setdefault(act["aid"], {"aid": act["aid"], "role": who, "activity": act, "items": []})
            entry["items"] = list(dict.fromkeys(entry["items"] + items[side]))
    order = {aid: k for k, aid in enumerate(target_order)}
    out = []
    for u in sorted(units.values(), key=lambda x: order.get(x["target_aid"], 99)):
        acts = list(u["activities"].values())
        # the target activity first, then the portfolio activities in the order the rows met them
        acts.sort(key=lambda e: e["role"] != "target")
        u["activities"] = acts
        out.append(u)
    return out


def needed(unit, legacy=False):
    """What a search must cover: every (activity, item), with a hash of the activity's content, so that an edited
    activity is searched again. legacy: the hash as earlier versions wrote it (it also hashed the fields that only
    record the lawyer's handling), so that a search saved by them is still recognised."""
    return sorted({(e["aid"], item, _content_hash(e["activity"], legacy)) for e in unit["activities"]
                   for item in e["items"]})


def _content_hash(act, legacy=False):
    content = {k: v for k, v in act.items() if k != "aid" and (legacy or k not in rules.STATE_FIELDS)}
    return hashlib.sha256(json.dumps(content, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()[:12]


def reusable(record, unit, retry_failed=True):
    """An earlier search can be kept if it covered every (activity, item) the unit needs now (e.g. after a row was
    dismissed, it covers more than needed; after a row was added back, it may not).
    retry_failed=False: only whether the rows changed since the search, ignoring whether it failed."""
    if not record:
        return False
    if retry_failed and (record.get("error") or failed_ids(record)):    # a partly failed search runs again
        return False
    if retry_failed and not record.get("levels_read"):     # made before markets had a level of trade: runs again
        return False
    have = {tuple(x) for x in record.get("covered") or []}
    return set(needed(unit)) <= have or set(needed(unit, legacy=True)) <= have


def row_covered(record, r, items):
    """Whether a stored search still covers every product of ONE row (the row's two activities unchanged). A search
    is made per target activity, so it goes out of date as soon as any of its rows changes (e.g. a pair added back);
    the other rows, whose products it still covers, keep their result until the search is updated."""
    if not record or items is None:
        return False
    have = {tuple(x) for x in record.get("covered") or []}
    for legacy in (False, True):
        need = {(act["aid"], item, _content_hash(act, legacy)) for act, side in ((r["a"], "a"), (r["b"], "b"))
                for item in items[side]}
        if need <= have:
            return True
    return False


def searched_before(record, r):
    """Whether both activities of a row were part of the stored search (then the row changed since; otherwise it is
    new to the search, e.g. a pair added back)."""
    seen = {x[0] for x in (record or {}).get("covered") or []}
    return bool(record) and {r["a"].get("aid"), r["b"].get("aid")} <= seen


def failed_ids(record):
    """The item ids whose type of product could not be searched. Also read from the types of an older record without
    'failed_items', so that a loaded audit log shows such items as failed, not as 'no precedent'."""
    out = set(record.get("failed_items") or [])
    return out | {iid for t in record.get("types") or [] if t.get("error") for iid in t.get("item_ids") or []}


# =============================================================== the anonymised input
def unit_input(unit, names):
    """The item list sent to the query and reflection calls: activities numbered 1, 2, ... (no company labels), each
    with its product line, level of trade and direct customers, and its items with ids such as [2.3]. Names removed in
    code. Returns (text, index {item_id: (aid, item)}, leftover names)."""
    lines, index = [], {}
    for k, e in enumerate(unit["activities"], start=1):
        lines += activity_head(k, e["activity"], status=True)
        for j, item in enumerate(e["items"], start=1):
            iid = f"{k}.{j}"
            index[iid] = (e["aid"], item)
            lines.append(f"[{iid}] {item}")
        lines.append("")
    text = rules.redact("\n".join(lines).strip(), names)
    return text, index, rules.find_names(text, names)


def items_text(unit, names, only=None):
    """The item list for some item ids only (one type of product), with the same numbering as unit_input and only the
    activities that have items in it."""
    lines = []
    for k, e in enumerate(unit["activities"], start=1):
        ids = [(f"{k}.{j}", item) for j, item in enumerate(e["items"], start=1) if only is None or f"{k}.{j}" in only]
        if not ids:
            continue
        lines += activity_head(k, e["activity"])
        lines += [f"[{iid}] {item}" for iid, item in ids] + [""]
    return rules.redact("\n".join(lines).strip(), names)


DESCRIPTION_CHARS = 600      # the merged "Other activities" line joins several descriptions


def activity_head(k, a, status=False):
    """The lines that introduce activity k in the query and reflection calls (names are removed by the caller).
    Includes what the activity IS, its description and main inputs, as in the abstract of step ③, so that items
    naming only a use ("ingredients for beverages") are not judged by the activity's name alone."""
    customers = rules._join(a.get("direct_customers"))
    details = a.get("customer_details") or "not stated"
    if details != "not stated":
        customers += f" ({details})"
    head = (f"Activity {k}: {a.get('product', 'not stated')} · level of trade: {a.get('value_chain_level', 'not stated')}"
            f" · direct customers: {customers}" + (f" · status: {a.get('status', 'not stated')}" if status else ""))
    description = re.sub(r"\s+", " ", a.get("description") or "").strip()
    if len(description) > DESCRIPTION_CHARS:
        description = description[:DESCRIPTION_CHARS].rsplit(" ", 1)[0] + " …"
    return [head, f"What it is: {description or 'not stated'} · main inputs: {rules._join(a.get('main_inputs'))}"]


def headings_of(p):
    """The decision's own headings above a paragraph, e.g. 'IV. COMPETITIVE ASSESSMENT > 1. RELEVANT PRODUCT MARKETS >
    C. Sweet biscuits' (empty if the corpus has none)."""
    return " > ".join(h for h in p.get("headings") or [] if h)


def paragraphs_text(paragraphs):
    """The retrieved paragraphs as the reflection sees them: id, decision, year, section, the decision's headings,
    text and footnotes.
    The headings matter: a general sentence such as "it can be left open how the product markets should be exactly
    defined" only makes sense together with the heading of the product it sits under."""
    out = []
    for p in paragraphs:
        notes = " ".join(f"[fn {f['n']}] {f['text']}" for f in p.get("footnotes") or [])
        head = f"[{p['id']}] {p['case']} {p['title']} ({p['date'][:4]}) · {p.get('section') or 'section not stated'}"
        if headings_of(p):
            head += f" · headings: {headings_of(p)}"
        out.append(head + "\n" + p["text"] + (f"\nFootnotes: {notes}" if notes else ""))
    return "\n\n".join(out)


# =============================================================== the AI calls (development cache as in step ③)
def _call(ai, step, schema, instructions, prompt, names, guard_text=None):
    """One structured call; invalid output: one retry with the fallback model. Returns (data or None, error).
    guard_text: the part of the prompt the guard checks (default: all of it); the retrieved public paragraphs are
    left out of the check."""
    leftover = rules.find_names(prompt if guard_text is None else guard_text, names)
    if leftover:
        return None, f"blocked: names found {leftover}"
    model = ai.model(step)
    # the reasoning effort is part of the key, so a test with another EFFORT_REFLECT never replays answers of a
    # different effort from the development cache
    path, hit = ai.cache_get(step, [model, ai.effort(step), instructions, schema.model_json_schema(), prompt])
    if hit:
        ai.log_cached(step, model)
        return hit, None
    for m in (model, ai.fallback()):
        try:
            resp = ai.respond(step, prompt, instructions=instructions, schema=schema, model=m)
        except Exception as e:  # noqa: BLE001 - reported, never hidden
            return None, f"call failed: {type(e).__name__}: {e}"
        if resp.output_parsed is not None:
            data = resp.output_parsed.model_dump()
            ai.cache_put(path, data)
            return data, None
    return None, "no valid answer from the model"


def cached_embed(ai):
    """Query embeddings through the AI gate (logged as 'embed_query'), with the development cache."""
    def embed(texts):
        texts = list(texts)
        path, hit = ai.cache_get("embed_query", [ai_embed_model(), texts])
        if hit:
            ai.log_cached("embed_query", ai_embed_model())
            return hit
        vectors = ai.embed(texts, note="stage 4 query", step="embed_query")
        ai.cache_put(path, vectors)
        return vectors
    return embed


def ai_embed_model():
    from logic.ai_client import EMBED_MODEL
    return EMBED_MODEL


# =============================================================== retrieval
def query_text(q):
    """The type of product of a query (older records kept a full query under 'query')."""
    return (q.get("products") or q.get("query") or "").strip()


def retrieve(retriever, queries, use_level):
    """Runs every type of product through the hybrid search (retrieval.py), with both questions of QUERY_FORMS,
    and returns (paragraph ids in order, the paragraphs, the trail per question). Only decision paragraphs are kept;
    each hit brings its neighbours (+/-1)."""
    order, paras, trail = [], {}, []
    # all questions of this step embedded in ONE request
    questions = [form.format(p=query_text(q)) for q in queries for form in QUERY_FORMS]
    vectors = dict(zip(questions, retriever.embed(questions))) if questions else {}
    for q in queries:
        level = q.get("level") if use_level and q.get("level") not in (None, "any") else None
        for form in QUERY_FORMS:
            question = form.format(p=query_text(q))
            res = retriever.search(question, k=POOL_PER_QUERY, level=level,      # the index read is locked inside
                                   vector=vectors.get(question))
            hits = [h for h in res["hits"] if h["paragraph"].get("source_type") == SOURCE_DECISION][:HITS_PER_FORM]
            trail.append({"query": question, "products": query_text(q), "level": q.get("level"),
                          "level_filter": res.get("level_filter"),
                          "level_filter_dropped": res.get("level_filter_dropped"),
                          "hits": [{"id": h["paragraph"]["id"], "found_by": h["found_by"],
                                    "rank_vector": h["rank_vector"], "rank_keyword": h["rank_keyword"],
                                    "score": h["score"], "neighbours": [n["id"] for n in h["neighbours"]]}
                                   for h in hits]})
            for h in hits:
                for p in [h["paragraph"]] + [n for n in h["neighbours"] if n.get("source_type") == SOURCE_DECISION]:
                    if p["id"] not in paras:
                        paras[p["id"]] = p
                        order.append(p["id"])
    return order, paras, trail


def _pool_order(order, trail):
    """Hits first (in query order), then the neighbours, at most MAX_PARAGRAPHS."""
    hits = [h["id"] for t in trail for h in t["hits"]]
    first = list(dict.fromkeys(hits))
    rest = [pid for pid in order if pid not in set(first)]
    return (first + rest)[:MAX_PARAGRAPHS]


# =============================================================== the loop (hard STOP, AI STOP, code STOP)
PARA_ID = re.compile(r"(M\.\s?\d+|Notice)\D{0,10}?(\d+)", re.IGNORECASE)


def norm_id(text):
    """'M.1234-21', 'M.1234 (21)', 'M.1234 para 21' -> 'M.1234-21'."""
    m = PARA_ID.search(text or "")
    if not m:
        return (text or "").strip()
    case = m.group(1).replace(" ", "")
    case = "Notice" if case.lower() == "notice" else "M." + case.split(".")[1]
    return f"{case}-{int(m.group(2))}"


def empty_record(unit, text="", index=None, error=""):
    return {"target_aid": unit["target_aid"], "target_product": unit.get("target_product", ""), "items_text": text,
            "index": {k: list(v) for k, v in (index or {}).items()}, "covered": [list(x) for x in needed(unit)],
            "rows": unit["rows"], "attempts": [], "markets": {}, "placements": {}, "rejected": [], "stop": error,
            "error": error, "paragraphs": {}, "levels_read": True}


class Progress:
    """How many types of product are planned and done in one run of step ④, for the progress bar (step ④ takes
    several minutes, so the bar moves per type, not per search). Thread-safe; the worker threads count, the script
    thread only reads."""

    def __init__(self):
        self._lock = threading.Lock()
        self.planned = self.done = 0

    def plan(self, n):
        with self._lock:
            self.planned += n

    def tick(self):
        with self._lock:
            self.done += 1


def run_unit(ai, unit, names, retriever, corpus=None, progress=None):
    """The search for one target activity: one AI call sorts the products into types of
    product; then each type is searched and placed on its own (run_type), in parallel; code merges the results.
    Returns the record that the table, 'Details' and the audit log read."""
    import concurrent.futures as cf
    text, index, leftover = unit_input(unit, names)
    record = empty_record(unit, text, index)
    record["types"] = []
    if leftover:
        record["error"] = record["stop"] = STOP_WORDS["blocked"] + f" ({', '.join(leftover)})"
        return record
    query_prompt = "ITEMS\n" + text
    plan, err = _call(ai, "query", schemas.QueryPlan, schemas.QUERY_INSTRUCTIONS, query_prompt, names)
    record["query_prompt"] = query_prompt
    if plan is None:
        record["error"] = record["stop"] = err
        return record
    types = assign_types(plan, index, unit, names)
    record["unassigned_searched"] = [i for t in types if t.get("extra") for i in t["item_ids"]]
    record["not_searched"] = [i for i in index if not any(i in t["item_ids"] for t in types)]
    if not types:
        record["error"] = record["stop"] = "the query step returned no type of product"
        return record
    with cf.ThreadPoolExecutor(TYPE_PARALLEL) as ex:
        if progress:
            progress.plan(len(types))

        def one(t):
            try:
                return run_type(ai, t, unit, index, names, retriever)
            finally:
                if progress:
                    progress.tick()
        results = list(ex.map(one, types))
    paras_all = {}
    for k, (t, res) in enumerate(zip(types, results), start=1):
        prefix = f"T{k}."
        res["markets"] = {prefix + mid: dict(m, market_id=prefix + mid) for mid, m in res["markets"].items()}
        res["placements"] = {iid: dict(p, market_ids=[prefix + m for m in p["market_ids"]])
                             for iid, p in res["placements"].items()}
        record["markets"].update(res["markets"])
        record["placements"].update(res["placements"])
        record["rejected"] += [f"{t['products']}: {x}" for x in res["rejected"]]
        paras_all.update(res.pop("paras"))
        record["types"].append({**t, **{k2: v for k2, v in res.items() if k2 not in ("markets", "placements")}})
    for iid in record["not_searched"]:
        record["placements"][iid] = {"market_ids": [], "basis": "none",
                                     "reason": "not searched: the query step assigned it to no type of product"}
    # the products of a type whose search failed (call error, or blocked by the guard) are marked "failed": shown as
    # a failed search, never as "no precedent", and the search runs again with "Update the market definitions"
    record["failed_items"] = []
    for t in record["types"]:
        if t.get("error"):
            for iid in t["item_ids"]:
                record["placements"][iid] = {"market_ids": [], "basis": "none", "fit": FIT_ONE, "failed": True,
                                             "reason": f"the search failed: {t['error']}"}
                record["failed_items"].append(iid)
    stops = [re.split(r"[:(]", t["stop"])[0].strip() for t in record["types"]]   # the reason without its details
    record["stop"] = f"{len(types)} types of product: " + ", ".join(f"{s} ×{stops.count(s)}" for s in dict.fromkeys(stops))
    errors = [t["error"] for t in record["types"] if t.get("error")]
    if errors and not record["markets"] and len(errors) == len(types):
        record["error"] = "; ".join(dict.fromkeys(errors))
    record["conclusions_taken"] = complete_conclusions(record["markets"])
    cited = {pid for m in record["markets"].values() for pid in m["product_paragraphs"]}
    record["paragraphs"] = {pid: _para_view(paras_all[pid], paras_all, corpus) for pid in cited if pid in paras_all}
    return record


def upgrade_market(m):
    """Older records without the decided / left-open split had one 'conclusion' quotation: it becomes the decided
    or the left-open passage, according to the label. Then separate_other_decision, so that a loaded audit log shows
    the same as a new search. Changes the market in place; idempotent."""
    if "decided_quote" not in m and "conclusion_quote" in m:
        part = "open" if m.get("conclusion") == "left open" else "decided"
        for f in ("quote", "paragraph", "quote_found"):
            m[f"{part}_{f}"] = m.get(f"conclusion_{f}", False if f == "quote_found" else "")
            other = "decided" if part == "open" else "open"
            m.setdefault(f"{other}_{f}", False if f == "quote_found" else "")
    return separate_other_decision(m)


def case_of(pid):
    """'M.1234-22' -> 'M.1234'."""
    return (pid or "").rpartition("-")[0]


def market_levels(m):
    """The levels of trade at which a market lies (a set; empty if not known). A built-in decision: its curated levels
    (build_corpus.MARKET_LEVELS), narrowed to the level the AI read from a verified passage if that level is one of
    them. A decision the lawyer added: the level the AI read from a passage verified word for word, else unknown."""
    cases = {case_of(pid) for pid in (m or {}).get("product_paragraphs") or [] if not pid.startswith("Notice")}
    read = (m or {}).get("level") if (m or {}).get("level_quote_found") else None
    if cases and all(c in MARKET_LEVELS for c in cases):
        curated = {lv for c in cases for lv in MARKET_LEVELS[c]}
        return {read} if read in curated else curated
    return {read} if read and read != NOT_LEVEL else set()


def level_fit(m, activity_level):
    """Whether a market is at the activity's level of trade: LEVEL_SAME, LEVEL_OTHER, or LEVEL_UNKNOWN (the market's
    level is not known, or the activity's level is not one of the levels of trade)."""
    levels = market_levels(m)
    if not levels or activity_level not in rules.VALUE_CHAIN_LEVELS or activity_level == "other":
        return LEVEL_UNKNOWN
    return LEVEL_SAME if activity_level in levels else LEVEL_OTHER


def separate_other_decision(m):
    """The decided and the left-open passage of one market must come from the same decision. The reflection sometimes
    combines a passage in which one decision defines a market with a passage in which a later decision leaves a
    further question open; the market would then be labelled "defined, a further question left open" under the first
    decision, although that decision left nothing open. The label follows the decision of the decided passage, and the
    other decision's passage is kept apart ('other_open_*') and shown as left open in THAT decision.
    Code, no AI call; changes the market in place; idempotent."""
    d, o = m.get("decided_paragraph"), m.get("open_paragraph")
    if m.get("decided_quote_found") and m.get("open_quote_found") and d and o and case_of(d) != case_of(o):
        m["other_open_quote"], m["other_open_paragraph"], m["other_open_quote_found"] = m["open_quote"], o, True
        m["open_quote"], m["open_paragraph"], m["open_quote_found"] = "", "", False
        if m.get("conclusion") == PARTLY:
            m["conclusion"] = "defined"
    return m


def _unverified(m):
    """A conclusion label that no passage verified word for word supports: kept for the audit log
    ('label_not_verified'), shown as 'not stated in these paragraphs'."""
    m["label_not_verified"] = m["conclusion"]
    m["conclusion"] = NOT_STATED


def verify_labels(record):
    """The same rule for a stored search (e.g. one loaded from a progress file): every conclusion label must rest on a
    decided or left-open passage verified word for word; a label without one becomes 'not stated in these
    paragraphs', and the market may then take the verified conclusion of the same market found by another call
    (complete_conclusions). Code, no AI call; changes the record in place; idempotent."""
    markets = record.get("markets") or {}
    changed = False
    for m in markets.values():
        upgrade_market(m)
        # a market without quotation fields has nothing to check and is left as it is
        if "decided_quote" in m and m.get("conclusion") in STATED and \
                not (m.get("decided_quote_found") or m.get("open_quote_found")):
            _unverified(m)
            changed = True
    if changed:
        complete_conclusions(markets)
    return record


def complete_conclusions(markets):
    """A market whose conclusion is not in the paragraphs of its own call takes the conclusion of the
    SAME market found by another call of the same search (same name, or one name ending with the other and both citing
    the same decision), with that call's paragraphs, so the citation shows where the conclusion is stated. Only if the
    other calls agree; a conclusion an AI call did state is never changed. Code, no AI call. Returns what was taken."""
    taken = []
    for mid, m in markets.items():
        if m.get("conclusion") != NOT_STATED:
            continue
        donors = [o for oid, o in markets.items() if oid != mid and o.get("conclusion") in STATED
                  and _same_market(m, o)]
        found = {o["conclusion"] for o in donors}
        if len(found) != 1:
            continue
        m["conclusion"] = found.pop()
        m["conclusion_from"] = [o["market_id"] for o in donors]
        quoted = next((o for o in donors if o.get("decided_quote_found") or o.get("open_quote_found")), None)
        if quoted:                       # the passages that state it, from the search that found them
            for part in ("decided", "open", "other_open"):
                for f in (f"{part}_quote", f"{part}_paragraph", f"{part}_quote_found"):
                    m[f] = quoted.get(f, "" if not f.endswith("found") else False)
        m["product_paragraphs"] = _sorted_ids(set(m["product_paragraphs"]) |
                                              {pid for o in donors for pid in o["product_paragraphs"]})
        taken.append(f"{mid} ({m['name']}): '{m['conclusion']}' taken from {', '.join(m['conclusion_from'])}")
    return taken


def _same_market(m, o):
    a, b = _market_key(m.get("name")), _market_key(o.get("name"))
    if not a or not b:
        return False
    if a == b:
        return True
    cases = lambda x: {pid.split("-")[0] for pid in x.get("product_paragraphs") or []}
    return (a.endswith(b) or b.endswith(a)) and bool(cases(m) & cases(o))


def assign_types(plan, index, unit, names):
    """The types of product of the query step, checked in code: only item ids that exist, each item in one type only
    (the first that names it); a type without valid items is dropped. Items the query step left out are searched on
    their own (their own words as the type, the level of their activity) if there are at most MAX_EXTRA of them;
    otherwise grouped per activity, with the activity's product line as the type. Every item is searched."""
    types, seen = [], set()
    for q in (plan.get("queries") or [])[:MAX_TYPES]:
        ids = [i.strip().strip("[]") for i in q.get("item_ids") or []]
        ids = [i for i in dict.fromkeys(ids) if i in index and i not in seen]
        if not ids or not query_text(q):
            continue
        seen.update(ids)
        types.append({"products": query_text(q), "level": q.get("level") or "any", "item_ids": ids})
    level_of = {e["aid"]: e["activity"].get("value_chain_level") or "any" for e in unit["activities"]}
    left = [i for i in index if i not in seen]
    if len(left) <= MAX_EXTRA:
        for iid in left:
            aid, item = index[iid]
            types.append({"products": rules.redact(item, names), "level": level_of.get(aid, "any"),
                          "item_ids": [iid], "extra": True})
        return split_by_level(types, index, level_of)
    product_of = {e["aid"]: e["activity"].get("product") or "" for e in unit["activities"]}
    by_activity = {}
    for iid in left:
        by_activity.setdefault(index[iid][0], []).append(iid)
    for aid, ids in by_activity.items():
        words = rules.redact(product_of.get(aid) or index[ids[0]][1], names)
        types.append({"products": words, "level": level_of.get(aid, "any"), "item_ids": ids, "extra": True})
    return split_by_level(types, index, level_of)


# a shop's or wholesaler's products are searched as the retail or wholesale of those products (legal terms, as the
# Commission names such markets), never together with the same products made by manufacturers
RESELLER_SEARCH = {"retail": "retail distribution of", "wholesale / distribution": "wholesale distribution of"}
RESELLER_TERMS = re.compile(r"\b(?:retail|wholesal|distribut)", re.IGNORECASE)


def split_by_level(types, index, level_of):
    """Every type of product that holds items of a shop or wholesaler is split: those items form a type of their own,
    at their level of trade, searched as the retail or wholesale distribution of the products. Code, after the query
    step (which is asked to do the same), so that it holds whatever the query step answered."""
    out = []
    for t in types:
        parts = {}
        for iid in t["item_ids"]:
            lv = level_of.get(index[iid][0])
            parts.setdefault(lv if lv in RESELLER_SEARCH else "", []).append(iid)
        for lv, ids in parts.items():
            if not lv:
                out.append(dict(t, item_ids=ids))
                continue
            words = t["products"] if RESELLER_TERMS.search(t["products"]) else f"{RESELLER_SEARCH[lv]} {t['products']}"
            out.append(dict(t, products=words, level=lv, item_ids=ids))
    return out


def run_type(ai, t, unit, index, names, retriever):
    """One type of product: retrieval (both questions), one small reflection on its items only, the loop with its three
    STOP conditions, the citation and item checks. Never raises: an error is returned with the type."""
    sub = {i: index[i] for i in t["item_ids"]}
    text = items_text(unit, names, only=set(sub))
    out = {"items_text": text, "attempts": [], "stop": "", "error": "", "kept_attempt": 0, "markets": {},
           "placements": {}, "rejected": [], "paras": {}}
    try:
        queries = [{"products": t["products"], "level": t["level"]}]
        pool, paras, best = [], {}, None
        for attempt in range(1, MAX_ATTEMPTS + 1):
            guard = rules.find_names(" ".join(query_text(q) for q in queries) + "\n" + text, names)
            if guard:                            # AI text and app text: checked like everything else that is sent
                out["stop"] = STOP_WORDS["blocked"] + f" ({', '.join(guard)})"
                break
            order, found, trail = retrieve(retriever, queries, use_level=(attempt == 1))
            new = [pid for pid in order if pid not in paras]
            step = {"attempt": attempt, "queries": queries, "level_filter": attempt == 1, "retrieval": trail,
                    "new_paragraphs": new}
            out["attempts"].append(step)
            if attempt > 1 and not new:
                out["stop"] = STOP_WORDS["same paragraphs"]
                break
            paras.update(found)
            pool = list(dict.fromkeys(pool + _pool_order(order, trail)))[:MAX_PARAGRAPHS + 8 * (attempt - 1)]
            # the decisions are public text and pass unchanged, even where they name a company of the screen; the
            # guard checks what the app and the AI write; such names are recorded for the audit log
            raw = paragraphs_text([paras[p] for p in pool])
            step["screen_names_in_paragraphs"] = rules.find_names(raw, names)
            prompt = "ITEMS\n" + text + "\n\nPARAGRAPHS\n" + raw
            data, err = _call(ai, "reflect", schemas.Reflection, schemas.REFLECTION_INSTRUCTIONS, prompt, names,
                              guard_text="ITEMS\n" + text)
            step["reflection_prompt"] = prompt
            step["paragraphs_sent"] = list(pool)
            if data is None:
                step["error"] = err
                out["stop"] = STOP_WORDS["failed"] + f" ({err})"
                break
            step["reflection"] = data
            result = check(data, sub, set(pool), paras)
            placed = sum(1 for p in result["placements"].values() if ids_of(p))
            step["checked"] = {"placed": placed, "items": len(sub), "rejected": result["rejected"]}
            # keep the better attempt: a second attempt can place FEWER items; on a tie the later one
            if best is None or placed >= sum(1 for p in best["placements"].values() if ids_of(p)):
                best, out["kept_attempt"] = result, attempt
            if placed == len(sub):
                out["stop"] = STOP_WORDS["all placed"]
                break
            if attempt == MAX_ATTEMPTS:
                out["stop"] = STOP_WORDS["attempts"]
                break
            queries = [{"products": query_text(q), "level": q.get("level") or "any"}
                       for q in data.get("rewrite_queries") or [] if query_text(q)][:MAX_REWRITE]
            if not queries:
                out["stop"] = STOP_WORDS["no rewrite"]
                break
        if best is None:
            out["error"] = out["stop"]
        else:
            out["markets"], out["placements"], out["rejected"] = best["markets"], best["placements"], best["rejected"]
        out["paras"] = paras
    except Exception as e:  # noqa: BLE001 - one type failing must not lose the others
        out["error"] = out["stop"] = f"the search failed: {type(e).__name__}: {e}"
    return out


def ids_of(p):
    """The markets a placement names: 'market_ids' (several per item), or 'market_id' in older records."""
    if not p:
        return []
    if "market_ids" in p:
        return [m for m in p["market_ids"] or [] if m and m != "none"]
    return [p["market_id"]] if p.get("market_id") not in (None, "", "none") else []


QUOTE_CHARS = str.maketrans({"’": "'", "‘": "'", "“": '"', "”": '"', "„": '"', "–": "-", "—": "-", "\u00a0": " "})


def _plain(text):
    """For comparing a quotation with a paragraph: footnote markers removed, quotes and dashes unified, spaces
    collapsed, lower case."""
    text = re.sub(r"\[fn [^\]]*\]|\(fn \d+\)", " ", (text or "").translate(QUOTE_CHARS))
    return re.sub(r"\s+", " ", text).strip().lower()


def check_quote(quote, pid, pool, paras):
    """(quote, found, paragraph id). The quotation must be in a decision paragraph that was sent; the paragraph given
    is tried first, then the others sent. Ellipses ('...') split the quotation into parts that must all be there."""
    quote = (quote or "").strip().strip('"“”').strip()
    pid = norm_id(pid or "") if pid else ""
    if not quote:
        return "", False, ""
    parts = [x.strip(" .,;:") for x in re.split(r"\.\.\.|…", _plain(quote)) if len(x.strip(" .,;:")) >= 12]
    if not parts:
        return quote, False, pid if pid in pool else ""
    order = ([pid] if pid in pool else []) + [x for x in pool if x != pid]
    for cand in order:
        p = paras.get(cand) or {}
        if p.get("source_type") != SOURCE_DECISION:
            continue
        text = _plain(p.get("text"))
        if all(x in text for x in parts):
            return quote, True, cand
    return quote, False, pid if pid in pool else ""


def check(data, index, pool, paras):
    """The citation check and the item check, in code: a paragraph may be cited only if the
    retrieval returned it in this search; a market left without any valid paragraph is dropped and its items count as
    'none'; an item id must exist; an item the reflection did not place counts as 'none'. Every correction is listed in
    'rejected' (shown in Details and the audit log)."""
    rejected, markets = [], {}
    for m in data.get("markets") or []:
        mid = (m.get("market_id") or "").strip()
        if not mid or mid.lower() == "none":
            continue
        prod = []
        for raw in m.get("product_paragraphs") or []:
            pid = norm_id(raw)
            if pid in pool and paras.get(pid, {}).get("source_type") == SOURCE_DECISION:
                if pid not in prod:
                    prod.append(pid)
            else:
                rejected.append(f"{mid}: paragraph {raw} was not among the paragraphs retrieved")
        if not prod:
            rejected.append(f"{mid} ({m.get('name', '')}): no valid paragraph left, market not used")
            continue
        markets[mid] = {"market_id": mid, "name": m.get("name") or "not stated", "conclusion": m.get("conclusion"),
                        "product_paragraphs": _sorted_ids(prod), "summary": m.get("summary") or ""}
        # what the Commission defined, in its own words, checked in code like the source quotations of
        # step ②: a quotation counts only if it is in a paragraph that was sent (if it is in another paragraph than
        # the one given, that one is used and the correction is listed)
        for part in ("decided", "open", "scope"):
            quote, found, where = check_quote(m.get(f"{part}_quote"), m.get(f"{part}_paragraph"), pool, paras)
            markets[mid][f"{part}_quote"] = quote
            markets[mid][f"{part}_paragraph"] = where
            markets[mid][f"{part}_quote_found"] = found
            if quote and not found:
                rejected.append(f"{mid}: the {part} quotation is not word for word in the paragraphs sent (not used "
                                "as a quotation)")
            elif found and where != norm_id(m.get(f"{part}_paragraph") or ""):
                rejected.append(f"{mid}: the {part} quotation is in paragraph {where}, not "
                                f"{m.get(f'{part}_paragraph') or 'the one given'} (corrected)")
        reasons = []
        for r in m.get("reasons") or []:
            pid = norm_id(r.get("paragraph") or "")
            if (r.get("reason") or "").strip():
                reasons.append({"reason": r["reason"].strip(),
                                "paragraph": pid if pid in pool and paras.get(pid, {}).get("source_type")
                                == SOURCE_DECISION else ""})
        markets[mid]["reasons"] = reasons
        # the level of trade of the market's sellers: used only where a passage verified word for word shows it
        level = m.get("level") or NOT_LEVEL
        quote, found, where = check_quote(m.get("level_quote"), m.get("level_paragraph"), pool, paras)
        markets[mid].update(level_as_found=level, level_quote=quote, level_paragraph=where, level_quote_found=found)
        if level != NOT_LEVEL and not found:
            rejected.append(f"{mid}: the level '{level}' rests on no passage found word for word in the paragraphs sent: "
                            "shown as not stated")
            level = NOT_LEVEL
        markets[mid]["level"] = level
        # the label follows the passages the code found word for word; a label of the AI that no such passage
        # supports is not reported as the Commission's conclusion
        d, o = markets[mid]["decided_quote_found"], markets[mid]["open_quote_found"]
        if d or o:
            markets[mid]["conclusion"] = PARTLY if d and o else "defined" if d else "left open"
        elif markets[mid]["conclusion"] in STATED:
            rejected.append(f"{mid}: the AI's label '{markets[mid]['conclusion']}' rests on no passage found word for "
                            f"word in the paragraphs sent: shown as '{NOT_STATED}'")
            _unverified(markets[mid])
        separate_other_decision(markets[mid])      # one decision per label
        if markets[mid].get("other_open_paragraph"):
            rejected.append(f"{mid}: the left-open passage is from {case_of(markets[mid]['other_open_paragraph'])}, "
                            f"not from {case_of(markets[mid]['decided_paragraph'])}: shown as left open in that "
                            "decision (corrected)")
        extra = {markets[mid]["decided_paragraph"], markets[mid]["open_paragraph"], markets[mid]["scope_paragraph"],
                 markets[mid].get("other_open_paragraph") or "", markets[mid]["level_paragraph"]} | \
            {r["paragraph"] for r in reasons}
        markets[mid]["product_paragraphs"] = _sorted_ids(set(prod) | {x for x in extra if x})
    placements = {}
    for p in data.get("placements") or []:
        iid = (p.get("item_id") or "").strip().strip("[]")
        if iid not in index:
            rejected.append(f"item id {p.get('item_id')} does not exist")
            continue
        if iid in placements:
            continue
        wanted = p.get("market_ids") if "market_ids" in p else [p.get("market_id")]
        mids = []
        for mid in wanted or []:
            mid = (mid or "").strip()
            if not mid or mid == "none":
                continue
            if mid in markets:
                if mid not in mids:
                    mids.append(mid)
            else:
                rejected.append(f"item {iid}: market {mid} not available")
        basis = p.get("basis") or "none"
        if not mids:
            basis = "none"
        elif basis == "none":
            basis = "analogy"           # placed but not called a precedent: the weaker label, for the lawyer to check
        # an item in several markets is either a range spanning them or one of them, unclear which;
        # if the reflection names several markets but calls it "one market", the cautious reading is "unclear which"
        fit = p.get("fit") or FIT_ONE
        if len(mids) <= 1:
            fit = FIT_ONE
        elif fit not in (FIT_RANGE, FIT_UNCLEAR, FIT_SAME):
            fit = FIT_UNCLEAR
        placements[iid] = {"market_ids": mids, "basis": basis, "fit": fit, "reason": p.get("reason") or ""}
    for iid in index:
        placements.setdefault(iid, {"market_ids": [], "basis": "none", "reason": "not placed by the reflection"})
    return {"markets": markets, "placements": placements, "rejected": rejected}


def _sorted_ids(ids):
    return sorted(ids, key=lambda pid: (pid.split("-")[0], int(pid.split("-")[1]) if pid.split("-")[-1].isdigit() else 0))


def _para_view(p, paras, corpus):
    """A cited paragraph as shown under 'Paragraphs': its text, footnotes, decision, link and the neighbours."""
    def neighbour(n):
        nid = f"{p['case']}-{n}"
        q = paras.get(nid) or (corpus or {}).get(nid)
        return {"id": nid, "text": q["text"]} if q else None
    return {"id": p["id"], "case": p["case"], "title": p["title"], "date": p["date"], "para": p["para"],
            "section": p.get("section"), "headings": p.get("headings") or [],      # shown in the hover
            "decision": p.get("decision"), "url": p.get("url"), "text": p["text"],
            "footnotes": p.get("footnotes") or [],
            "neighbours": [x for x in (neighbour(p["para"] - 1), neighbour(p["para"] + 1)) if x],
            # a decision the lawyer added for this screen (uploads.py); the key is absent for the built-in corpus
            **({"user_provided": True} if p.get("user_provided") else {})}


# =============================================================== what one row shows (code)
def side_markets(record, aid, items, product_line="", level=None):
    """For one side of a row: [{market_id, market, basis, items, notes, status, other_level, level_unknown}], items
    grouped by the market(s) they were placed in (an item placed in several markets appears in each).
    level: the activity's level of trade. A market at another level is not the side's own market: its group has
    other_level=True (context only), and an item placed only in such markets also counts as "none" (no precedent at its
    level). A market whose level is not known stays the side's market, but never as an exact match (basis "analogy",
    level_unknown=True).
    Each product belongs to ONE market, so an item in several markets only shows that the side is
    somewhere in them. status per market: "specific" if an item was placed in this market alone; "possibly" if only
    items that could be in one of several markets (unclear which) lead here; "general" if only a general term leads
    here: an item that is a range spanning several markets, or the activity's own name placed in several markets.
    notes: {item: why it is not specific}, shown next to the item."""
    by_item = {(v[0], v[1]): iid for iid, v in (record.get("index") or {}).items()}
    markets = record.get("markets") or {}
    name_key = rules._norm(product_line)
    failed = failed_ids(record)
    groups = {}
    for item in items:
        iid = by_item.get((aid, item))
        p = (record.get("placements") or {}).get(iid) if iid else None
        if iid in failed and not ids_of(p):
            p = dict(p or {}, failed=True)
        if p and p.get("failed"):        # a failed search, never shown as "no precedent"
            g = groups.setdefault("failed", {"market": None, "basis": set(), "items": [], "notes": {}, "kinds": set()})
            g["basis"].add("none")
            g["items"].append(item)
            g["kinds"].add("specific")
            g["notes"][item] = p.get("reason") or "the search failed"
            continue
        mids = [m for m in ids_of(p) if m in markets] or ["none"]
        basis = p["basis"] if p and mids != ["none"] else "none"
        fits = {mid: level_fit(markets[mid], level) for mid in mids if mid != "none"}
        if mids != ["none"] and all(f == LEVEL_OTHER for f in fits.values()):
            g = groups.setdefault("none", {"market": None, "basis": set(), "items": [], "notes": {}, "kinds": set()})
            g["basis"].add("none")
            g["items"].append(item)
            g["kinds"].add("specific")
        # older records have no "fit": their prompt allowed several markets only "where the item spans several
        # markets", i.e. a range
        fit = (p or {}).get("fit") or (FIT_RANGE if len(mids) > 1 else FIT_ONE)
        others = " or ".join((markets.get(m) or {}).get("name", m) for m in mids)
        if len(mids) > 1 and fit == FIT_SAME:
            kind, note = "specific", ""                 # one market, described in several decisions
        elif len(mids) > 1 and (fit == FIT_RANGE or rules._norm(item) == name_key):
            kind, note = "general", ("activity name, spans several markets" if rules._norm(item) == name_key
                                     else "a range spanning several markets")
        elif len(mids) > 1 and fit == FIT_UNCLEAR:
            kind, note = "possibly", f"{others}, unclear which"
        else:
            kind, note = "specific", ""
        for mid in mids:
            fit_level = fits.get(mid)
            key = "ctx:" + mid if fit_level == LEVEL_OTHER else mid
            g = groups.setdefault(key, {"market": markets.get(mid), "basis": set(), "items": [], "notes": {},
                                        "kinds": set(), "mid": mid, "other_level": fit_level == LEVEL_OTHER,
                                        "level_unknown": fit_level == LEVEL_UNKNOWN})
            g["basis"].add("analogy" if fit_level == LEVEL_UNKNOWN and basis == "precedent" else basis)
            g["items"].append(item)
            g["kinds"].add(kind)
            if note:
                g["notes"][item] = note
    out = []
    for key, g in groups.items():
        basis = "precedent" if "precedent" in g["basis"] else "analogy" if "analogy" in g["basis"] else "none"
        status = next(k for k in ("specific", "possibly", "general") if k in g["kinds"])
        out.append({"market_id": g.get("mid", key), "market": g["market"], "basis": basis, "items": g["items"],
                    "notes": g["notes"], "status": status, "other_level": bool(g.get("other_level")),
                    "level_unknown": bool(g.get("level_unknown"))})
    out.sort(key=lambda x: (x["other_level"], x["market_id"] in ("none", "failed"), x["market_id"]))
    return out


def row_view(r, record, overrides, effective_status, dismissed_parts):
    """Everything the market column and the 'under the precedent' line of one row show, from the stored search.
    Returns None if the row is not kept or not searched yet. Pure code."""
    items = row_items(r, overrides, effective_status, dismissed_parts)
    if items is None or not record:
        return None
    levels = {"a": r["a"].get("value_chain_level"), "b": r["b"].get("value_chain_level")}
    if record.get("error") and not record.get("markets"):
        return {"error": record["error"], "a": [], "b": [], "a_ctx": [], "b_ctx": [], "levels": levels,
                "verdict": None, "unplaced": items["a"] + items["b"], "failed": []}
    sides = {s: side_markets(record, r[s]["aid"], items[s], r[s].get("product", ""), levels[s]) for s in ("a", "b")}
    a = [g for g in sides["a"] if not g["other_level"]]
    b = [g for g in sides["b"] if not g["other_level"]]
    # markets of a side's products at another level of trade: context, not the side's own market
    view = {"error": "", "a": a, "b": b, "a_ctx": [g for g in sides["a"] if g["other_level"]],
            "b_ctx": [g for g in sides["b"] if g["other_level"]], "levels": levels, "verdict": None,
            "unplaced": [i for g in a + b if g["market_id"] == "none" for i in g["items"]],
            "failed": [i for g in a + b if g["market_id"] == "failed" for i in g["items"]]}
    d = r["decision"]
    off = set(dismissed_parts(r, overrides))
    if d.get("horizontal") and "horizontal" not in off and effective_status(r, overrides) == "candidate":
        view["verdict"] = horizontal_verdict(record, r, items, a, b)
    return view


def horizontal_verdict(record, r, items, a, b):
    """Where the precedent puts the two sides of a horizontal row (separate from row_view, so that the display can
    also apply it to a horizontal overlap the lawyer added to a row, without a new search)."""
    # each type of product is placed in its own call, which names its own markets. Markets of
    # different calls count as one market only if they have the same name; "different markets under the
    # precedent" is claimed only if products of both sides were placed in the SAME call (never across calls)
    key = {mid: _market_key(m["name"]) for mid, m in (record.get("markets") or {}).items()}
    k_of = lambda g: key.get(g["market_id"], g["market_id"])  # noqa: E731

    def by_key(groups):
        out = {}
        for g in groups:
            if g["market_id"] in ("none", "failed"):
                continue
            k = k_of(g)
            o = out.setdefault(k, {"group": g, "basis": set(), "status": set()})
            o["basis"].add(g["basis"])
            o["status"].add(g["status"])
        for o in out.values():
            o["basis"] = "precedent" if o["basis"] == {"precedent"} else "analogy"
            o["status"] = next(s for s in ("specific", "possibly", "general") if s in o["status"])
        return out
    ma, mb = by_key(a), by_key(b)
    shared = [k for k in ma if k in mb]
    # two activities at different levels of trade, each with a market at its own level: separate markets at different
    # levels (Market Definition Notice (14)), not two products the Commission split at the same level
    la, lb = r["a"].get("value_chain_level"), r["b"].get("value_chain_level")
    across = la != lb and all(x in rules.VALUE_CHAIN_LEVELS and x != "other" for x in (la, lb))

    def line(k):
        # a shared market counts as "precedent" only if it is a precedent for both sides (one side may be placed
        # there only by analogy); the status is the weaker of the two sides
        g = ma[k]["group"]
        basis = "precedent" if ma[k]["basis"] == mb[k]["basis"] == "precedent" else "analogy"
        st = {ma[k]["status"], mb[k]["status"]}
        status = "general" if "general" in st else "possibly" if "possibly" in st else "specific"
        return dict(g, basis=basis, status=status)
    rows = [line(k) for k in shared]
    return {
        # "both in" only where an item of EACH side was placed in that market alone
        "both": [g for g in rows if g["status"] == "specific"],
        "possibly": [g for g in rows if g["status"] == "possibly"],
        "general": [g for g in rows if g["status"] == "general"],
        "only_a": [o["group"] for k, o in ma.items() if k not in mb],
        "only_b": [o["group"] for k, o in mb.items() if k not in ma],
        # the precedent puts the two companies' items into different markets: shown, never deleted
        "different": bool(ma and mb and not shared and not across and _same_call(record, r, items)),
        "levels_differ": bool(ma and mb and not shared and across),
        "left_open": any((g["market"] or {}).get("conclusion") in ("left open", PARTLY) for g in a + b
                         if g["market"]),
        "not_stated": any((g["market"] or {}).get("conclusion") == NOT_STATED for g in a + b if g["market"]),
    }


MARKET_PREFIX = re.compile(r"^(the\s+)?(relevant\s+)?(product\s+)?markets?\s+(for|of)\s+(the\s+)?")


# words that change how a market is named, not which market it is
MARKET_FILLER = {"a", "an", "the", "as", "separate", "possible"}


def _market_key(name):
    """One key for the different wordings of one market: 'Market for e-bikes', 'the market for e-bikes' and 'e-bikes'
    are one market, and so are 'X as a separate market within Y' and 'X within the Y market'."""
    words = [w for w in (name or "").lower().split() if w not in MARKET_FILLER]
    name = MARKET_PREFIX.sub("", " ".join(words))
    name = " ".join(w for w in name.split() if w not in ("market", "markets"))
    return re.sub(r"[^a-z0-9]", "", name)


def unify_names(records):
    """Each AI call names its own markets, so one market can come back in several wordings (see _market_key). Every
    wording of one market is shown under its shortest one; the AI's own wording is kept in "name_as_found"."""
    markets = [m for rec in records if isinstance(rec, dict) for m in (rec.get("markets") or {}).values()]
    shortest = {}
    for m in markets:
        name = m.get("name_as_found") or m.get("name") or ""
        k = _market_key(name)
        if k and (k not in shortest or (len(name), name) < (len(shortest[k]), shortest[k])):
            shortest[k] = name
    for m in markets:
        name = m.get("name_as_found") or m.get("name") or ""
        best = shortest.get(_market_key(name))
        if best and best != name:
            m["name_as_found"], m["name"] = name, best


def _same_call(record, r, items):
    """Whether at least one product of each side of the row was placed in the same reflection call. Older records had
    one call for all products."""
    types = record.get("types")
    if not types:
        return True
    by_item = {(v[0], v[1]): iid for iid, v in (record.get("index") or {}).items()}
    call_of = {iid: k for k, t in enumerate(types) for iid in t["item_ids"]}
    ca = {call_of.get(by_item.get((r["a"]["aid"], i))) for i in items["a"]} - {None}
    cb = {call_of.get(by_item.get((r["b"]["aid"], i))) for i in items["b"]} - {None}
    return bool(ca & cb)


def summary(records):
    """Counts for the line above the table: searches, markets, placed items, by basis."""
    placed = [p for rec in records for p in (rec.get("placements") or {}).values()]
    return {"searches": len(records), "markets": sum(len(rec.get("markets") or {}) for rec in records),
            "items": len(placed), "precedent": sum(p["basis"] == "precedent" for p in placed),
            "analogy": sum(p["basis"] == "analogy" for p in placed),
            "none": sum(p["basis"] == "none" and not p.get("failed") for p in placed),
            "failed": sum(len(failed_ids(rec)) for rec in records if not rec.get("error")),
            "rejected": sum(len(rec.get("rejected") or []) for rec in records),
            "errors": [rec["error"] for rec in records if rec.get("error")]
            + [f"{rec.get('target_product') or 'one activity'}: the search failed for {len(failed_ids(rec))} of "
               f"its products" for rec in records if failed_ids(rec) and not rec.get("error")]}